#!/usr/bin/env python3
"""Despaghettify hub CLI — automates scan metrics and DS preflight for agent skills.

Preferred invocations (repo root on ``PYTHONPATH``, or cwd = repo root for ``-m``):
  python -m despaghettify.tools check
  python -m despaghettify.tools solve-preflight --ds DS-016
  python -m despaghettify.tools wave-plan-validate --file despaghettify/tools/fixtures/despag_wave_plan_example_valid.json
  python -m despaghettify.tools open-ds

After ``pip install -e .`` from repo root (optional ``pyproject.toml`` hub package): ``despag-check`` / ``wos-despag`` — same CLI.

Script path (always valid):
  python despaghettify/tools/despaghettify.py check

Also: despaghettify/tools/wave_plan_emit.py (Markdown ↔ wave_plan.json); autonomous loop (`autonomous-init`, `autonomous-advance`, `autonomous-status`, `autonomous-verify`); `setup-sync`, `metrics-emit`, `trigger-eval`. See despaghettify/superpowers/references/CLI.md and despaghettify/README.md.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

# Repo root: this file is despaghettify/tools/despaghettify.py
ROOT = Path(__file__).resolve().parent.parent.parent
INPUT_LIST = ROOT / "despaghettify" / "despaghettification_implementation_input.md"
RUNTIME_DIR = ROOT / "backend" / "app" / "runtime"
DESPAG_TOOLS_DIR = ROOT / "despaghettify" / "tools"

# Information input list table: open rows use | **DS-nnn** |
OPEN_DS_ROW = re.compile(r"^\|\s*\*\*(DS-\d+)\*\*\s*\|")
# Closed history rows in the same table
CLOSED_DS_ROW = re.compile(r"^\|\s*~~(DS-\d+)~~")
BACKTICK_CHUNK = re.compile(r"`([^`]{1,400})`")
# Distinct gate-like tokens (lowercase keys for counting)
_GATE_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("pytest", re.compile(r"\bpytest\b", re.I)),
    ("ds005", re.compile(r"\bds005\b", re.I)),
    ("ruff", re.compile(r"\bruff\b", re.I)),
    ("mypy", re.compile(r"\bmypy\b", re.I)),
    ("mkdocs", re.compile(r"\bmkdocs\b", re.I)),
    ("npm", re.compile(r"\bnpm\b", re.I)),
    ("cargo", re.compile(r"\bcargo\b", re.I)),
    ("pre_commit", re.compile(r"pre-commit|pre_commit", re.I)),
)


def _ensure_repo_root() -> None:
    if not (ROOT / "despaghettify").is_dir():
        print(
            "Repository root not found (expected despaghettify/ next to resolved hub). "
            "Run with repo root as cwd, or: python -m despaghettify.tools … (see despaghettify/README.md).",
            file=sys.stderr,
        )
        raise SystemExit(3)


def _load_input_list_text() -> str:
    if not INPUT_LIST.is_file():
        print(f"Missing {INPUT_LIST.relative_to(ROOT)}", file=sys.stderr)
        raise SystemExit(3)
    return INPUT_LIST.read_text(encoding="utf-8", errors="replace")


def _information_input_section(md: str) -> str:
    start = md.find("## Information input list")
    end = md.find("## Recommended implementation order")
    if start == -1 or end == -1 or end <= start:
        print("Could not slice Information input list section.", file=sys.stderr)
        raise SystemExit(3)
    return md[start:end]


def _preflight_input_bundle(override_path: str | None) -> tuple[str, Path]:
    """Return (markdown, path_shown_in_json)."""
    if not override_path or not override_path.strip():
        return _load_input_list_text(), INPUT_LIST
    p = Path(override_path.strip())
    if not p.is_absolute():
        p = ROOT / p
    fixtures = (ROOT / "despaghettify" / "tools" / "fixtures").resolve()
    try:
        p.resolve().relative_to(fixtures)
    except ValueError:
        print(
            "solve-preflight: --override-input-list must resolve under despaghettify/tools/fixtures/",
            file=sys.stderr,
        )
        raise SystemExit(3)
    if not p.is_file():
        print(f"Not a file: {p}", file=sys.stderr)
        raise SystemExit(3)
    return p.read_text(encoding="utf-8", errors="replace"), p


def cmd_open_ds(_args: argparse.Namespace) -> int:
    _ensure_repo_root()
    md = _load_input_list_text()
    section = _information_input_section(md)
    seen: set[str] = set()
    for line in section.splitlines():
        m = OPEN_DS_ROW.match(line)
        if m:
            seen.add(m.group(1))
    for line in sorted(seen, key=lambda s: int(s.split("-")[1])):
        print(line)
    return 0


def _parse_md_table_row_cells(line: str) -> list[str]:
    line = line.strip()
    if not (line.startswith("|") and line.endswith("|")):
        return []
    inner = line[1:-1]
    return [c.strip() for c in inner.split("|")]


def _path_like_backticks(text: str) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for m in BACKTICK_CHUNK.finditer(text):
        chunk = m.group(1).strip()
        for piece in re.split(r",\s*", chunk):
            p = piece.strip()
            if not p:
                continue
            if "/" not in p and not p.endswith(".py") and not p.endswith(".ts"):
                continue
            tok = p.split("(")[0].strip()
            tok = tok.split()[0] if tok else ""
            if tok and tok not in seen:
                seen.add(tok)
                ordered.append(tok)
    return ordered


def _gate_keywords_in_text(text: str) -> list[str]:
    found: list[str] = []
    for name, pat in _GATE_PATTERNS:
        if pat.search(text) and name not in found:
            found.append(name)
    return found


def _wave_sizing_heuristic(row_line: str) -> dict:
    """Rough, machine-printed hints — agents still choose honest N from the DS row."""
    cells = _parse_md_table_row_cells(row_line)
    focus = row_line
    if len(cells) >= 5:
        focus = " | ".join(cells[2:6])
    paths = _path_like_backticks(row_line)
    gates = _gate_keywords_in_text(row_line)
    ast_signal = 1 if re.search(r"\bAST\b", focus) else 0
    effort = min(8, len(paths)) + len(gates) + ast_signal
    if effort <= 1:
        n_min, n_max = 1, 2
    elif effort == 2:
        n_min, n_max = 1, 3
    elif effort <= 4:
        n_min, n_max = 2, 4
    elif effort <= 6:
        n_min, n_max = 3, 6
    else:
        n_min, n_max = 4, 8
    split_ds_recommended = effort >= 8
    return {
        "effort_score": effort,
        "path_signals": paths[:20],
        "path_signal_count": len(paths),
        "gate_keywords": gates,
        "ast_column_signal": bool(ast_signal),
        "n_suggested_min": n_min,
        "n_suggested_max": n_max,
        "split_ds_recommended": split_ds_recommended,
        "note": "Heuristic only; choose N from DS direction and governance. If honest N > 8, split DS rows per solve task.",
    }


def validate_wave_plan_document(
    data: object,
    *,
    repo_root: Path | None = None,
    check_primary_paths: bool = False,
    gate_prefix_allowlist: tuple[str, ...] | None = None,
) -> tuple[bool, list[str]]:
    """Return (ok, errors). Optional strict checks for CI or pre-merge."""
    errs: list[str] = []
    if not isinstance(data, dict):
        return False, ["root must be a JSON object"]
    ver = data.get("schema_version")
    if ver != "1" and ver != 1:
        errs.append('schema_version must be 1 (JSON number) or "1" (string)')
    raw_ds = data.get("ds_id")
    if not isinstance(raw_ds, str) or not re.fullmatch(r"(?i)DS-\d+", raw_ds.strip()):
        errs.append("ds_id must be a string matching DS-<digits> (e.g. DS-016)")
    slug = data.get("slug", None)
    if slug is not None and (not isinstance(slug, str) or not str(slug).strip()):
        errs.append("slug, when present, must be a non-empty string")
    session_date = data.get("session_date", None)
    if session_date is not None and (not isinstance(session_date, str) or not session_date.strip()):
        errs.append("session_date, when present, must be a non-empty string")
    waves = data.get("sub_waves")
    if not isinstance(waves, list) or len(waves) < 1:
        errs.append("sub_waves must be a non-empty array")
        return False, errs
    if len(waves) > 8:
        errs.append("sub_waves length > 8 violates solve-task policy; split DS rows")
    for i, w in enumerate(waves):
        prefix = f"sub_waves[{i}]"
        if not isinstance(w, dict):
            errs.append(f"{prefix} must be an object")
            continue
        idx = w.get("index")
        if not isinstance(idx, int) or idx < 1:
            errs.append(f"{prefix}.index must be int >= 1")
        wid = w.get("id")
        if not isinstance(wid, str) or not wid.strip():
            errs.append(f"{prefix}.id must be a non-empty string (e.g. w01)")
        goal = w.get("goal")
        if not isinstance(goal, str) or not goal.strip():
            errs.append(f"{prefix}.goal must be a non-empty string")
        gates = w.get("gate_commands")
        if not isinstance(gates, list) or len(gates) < 1:
            errs.append(f"{prefix}.gate_commands must be a non-empty array of strings")
        else:
            for j, g in enumerate(gates):
                if not isinstance(g, str) or not g.strip():
                    errs.append(f"{prefix}.gate_commands[{j}] must be a non-empty string")
        pp = w.get("primary_paths")
        if pp is None:
            pass
        elif not isinstance(pp, list):
            errs.append(f"{prefix}.primary_paths must be an array when present")
        else:
            for j, p in enumerate(pp):
                if not isinstance(p, str) or not p.strip():
                    errs.append(f"{prefix}.primary_paths[{j}] must be a non-empty string")
    dict_waves = [w for w in waves if isinstance(w, dict)]
    if len(dict_waves) == len(waves) and not errs:
        indices = [w.get("index") for w in dict_waves]
        if all(isinstance(i, int) for i in indices) and sorted(indices) != list(
            range(1, len(waves) + 1)
        ):
            errs.append("sub_waves[].index must be 1..N with no gaps or duplicates")

    if not errs:
        cw = data.get("completed_wave_ids")
        if cw is not None:
            if not isinstance(cw, list) or not all(isinstance(x, str) and x.strip() for x in cw):
                errs.append("completed_wave_ids must be an array of non-empty strings when present")
            else:
                ids_in_waves = {w.get("id") for w in dict_waves if isinstance(w.get("id"), str)}
                for c in cw:
                    if c.strip() not in ids_in_waves:
                        errs.append(
                            f"completed_wave_ids entry {c.strip()!r} is not a sub_wave.id "
                            f"(known: {sorted(ids_in_waves)})"
                        )
        ni = data.get("next_index")
        if ni is not None:
            if not isinstance(ni, int) or ni < 1 or ni > len(waves) + 1:
                errs.append(
                    f"next_index must be int in 1..{len(waves) + 1} when present "
                    "(use N+1 when all waves are done)"
                )

    if not errs and gate_prefix_allowlist:
        prefixes = tuple(p.strip() for p in gate_prefix_allowlist if p.strip())
        if prefixes:
            for i, w in enumerate(dict_waves):
                gates = w.get("gate_commands") if isinstance(w, dict) else None
                if not isinstance(gates, list):
                    continue
                for j, g in enumerate(gates):
                    if not isinstance(g, str) or not g.strip():
                        continue
                    g2 = g.strip()
                    if not any(g2.startswith(p) for p in prefixes):
                        errs.append(
                            f"sub_waves[{i}].gate_commands[{j}] must start with one of {prefixes!r} "
                            "(--gate-prefix-allowlist)"
                        )

    if not errs and check_primary_paths:
        base = repo_root or ROOT
        base = base.resolve()
        for i, w in enumerate(dict_waves):
            pplist = w.get("primary_paths") if isinstance(w, dict) else None
            if not isinstance(pplist, list):
                continue
            for j, rel in enumerate(pplist):
                if not isinstance(rel, str) or not rel.strip():
                    continue
                target = (base / rel).resolve()
                try:
                    target.relative_to(base)
                except ValueError:
                    errs.append(f"sub_waves[{i}].primary_paths[{j}] escapes repo_root: {rel}")
                    continue
                if not target.exists():
                    errs.append(f"sub_waves[{i}].primary_paths[{j}] not found under repo: {rel}")

    return len(errs) == 0, errs


def cmd_wave_plan_validate(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    path = Path(args.file)
    if not path.is_absolute():
        path = ROOT / path
    if not path.is_file():
        print(f"Not a file: {path}", file=sys.stderr)
        return 3
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="strict"))
    except (OSError, json.JSONDecodeError) as e:
        print(str(e), file=sys.stderr)
        return 3
    allow = tuple(
        p.strip()
        for p in (args.gate_prefix_allowlist or "").split(",")
        if p.strip()
    )
    allow_t: tuple[str, ...] | None = allow if allow else None
    ok, errors = validate_wave_plan_document(
        data,
        repo_root=ROOT,
        check_primary_paths=bool(args.check_primary_paths),
        gate_prefix_allowlist=allow_t,
    )
    if ok:
        print(json.dumps({"ok": True, "file": path.relative_to(ROOT).as_posix()}, indent=2))
        return 0
    print(json.dumps({"ok": False, "errors": errors}, indent=2), file=sys.stderr)
    return 2


def cmd_solve_preflight(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    raw = (args.ds or "").strip()
    m = re.fullmatch(r"(?i)DS-(\d+)", raw)
    if not m:
        print("Use --ds DS-016 (form DS-<digits>).", file=sys.stderr)
        return 3
    ds_id = f"DS-{m.group(1)}"

    md, list_src = _preflight_input_bundle((args.override_input_list or "").strip() or None)
    section = _information_input_section(md)
    open_hit = False
    closed_hit = False
    row_line: str | None = None
    for line in section.splitlines():
        if f"~~{ds_id}~~" in line:
            closed_hit = True
        om = OPEN_DS_ROW.match(line)
        if om and om.group(1) == ds_id:
            open_hit = True
            row_line = line

    if open_hit:
        wave_sizing = _wave_sizing_heuristic(row_line) if row_line else {}
        print(
            json.dumps(
                {
                    "ds_id": ds_id,
                    "status": "open",
                    "input_list": list_src.relative_to(ROOT).as_posix(),
                    "wave_sizing": wave_sizing,
                },
                indent=2,
            )
        )
        return 0
    if closed_hit:
        print(
            json.dumps(
                {
                    "ds_id": ds_id,
                    "status": "closed",
                    "message": "row struck through / CLOSED in Information input list",
                },
                indent=2,
            )
        )
        return 2
    print(
        json.dumps(
            {
                "ds_id": ds_id,
                "status": "missing",
                "message": "no **DS-** open row in Information input list section",
            },
            indent=2,
        )
    )
    return 2


def _grep_runtime_cycle_hints() -> dict:
    patterns = ("TYPE_CHECKING", "avoid circular", "circular dependency")
    hits: list[dict] = []
    if not RUNTIME_DIR.is_dir():
        return {"runtime_dir_exists": False, "hit_count": 0, "hits": []}
    for path in sorted(RUNTIME_DIR.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            lower = line.lower()
            if any(p.lower() in lower for p in patterns):
                hits.append({"path": path.relative_to(ROOT).as_posix(), "line": i, "snippet": line.strip()[:200]})
    return {"runtime_dir_exists": True, "hit_count": len(hits), "hits": hits[:50]}


def _grep_builtins_goc_def() -> dict:
    """Match spaghetti-check extra check: def build_god_of_carnage_solo in **/builtins.py."""
    needle = "def build_god_of_carnage_solo"
    matches: list[str] = []
    for root in (ROOT / "backend", ROOT / "world-engine"):
        if not root.is_dir():
            continue
        for path in root.rglob("builtins.py"):
            try:
                txt = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if needle in txt:
                matches.append(path.relative_to(ROOT).as_posix())
    goc_template = ROOT / "story_runtime_core" / "goc_solo_builtin_template.py"
    template_has = goc_template.is_file() and needle in goc_template.read_text(
        encoding="utf-8", errors="replace"
    )
    return {
        "def_in_builtins_py_paths": matches,
        "count_in_builtins_py": len(matches),
        "goc_solo_builtin_template_has_def": template_has,
    }


def cmd_check(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    sys.path.insert(0, str(DESPAG_TOOLS_DIR))
    import spaghetti_ast_scan as sas  # noqa: PLC0415

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    ast_stats = sas.collect_ast_stats()
    ds005 = subprocess.run(
        [sys.executable, str(DESPAG_TOOLS_DIR / "ds005_runtime_import_check.py")],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    ds005_lines = [ln for ln in (ds005.stdout or "").splitlines() if ln.strip()]
    report: dict = {
        "kind": "despaghettify_check",
        "generated_at_utc": ts,
        "repo_root": ROOT.as_posix(),
        "ast": ast_stats,
        "ds005": {
            "exit_code": ds005.returncode,
            "import_ok_count": len([ln for ln in ds005_lines if ln.startswith("import_ok")]),
            "stdout_tail": ds005_lines[-5:] if ds005_lines else [],
        },
        "extra_builtins_goc": _grep_builtins_goc_def(),
        "extra_runtime_grep": _grep_runtime_cycle_hints(),
    }
    if getattr(args, "with_metrics", False):
        setup_path = ROOT / "despaghettify" / "spaghetti-setup.json"
        if setup_path.is_file():
            try:
                from despaghettify.tools.metrics_bundle import build_metrics_bundle  # noqa: PLC0415

                setup = json.loads(setup_path.read_text(encoding="utf-8"))
                report["metrics_bundle"] = build_metrics_bundle(
                    check_payload=report,
                    setup=setup,
                )
            except (OSError, json.JSONDecodeError, KeyError, TypeError):
                pass
    text = json.dumps(report, indent=2)
    if args.out:
        out_path = Path(args.out)
        if not out_path.is_absolute():
            out_path = ROOT / out_path
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(text + "\n", encoding="utf-8")
        print(str(out_path.relative_to(ROOT)))
    else:
        print(text)
    if ds005.returncode != 0:
        print(ds005.stderr or "", file=sys.stderr)
        return 1
    return 0


def cmd_autonomous_init(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools import autonomous_loop as al  # noqa: PLC0415

    code, msg, _state = al.init_session(force=bool(args.force))
    if code != 0:
        print(msg, file=sys.stderr)
    else:
        print(msg)
    return code


def cmd_autonomous_advance(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools import autonomous_loop as al  # noqa: PLC0415

    kind = args.kind.strip().lower().replace("-", "_")
    if kind not in ("backlog_solve", "main_check", "main_solve"):
        print("kind must be backlog-solve | main-check | main-solve", file=sys.stderr)
        return 2
    res = al.advance(
        kind,  # type: ignore[arg-type]
        ds=args.ds.strip() if args.ds else None,
        check_json=args.check_json.strip() if args.check_json else None,
    )
    print(res.message)
    if not res.ok:
        print(res.message, file=sys.stderr)
    return res.exit_code


def cmd_autonomous_status(_args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools import autonomous_loop as al  # noqa: PLC0415

    print(json.dumps(al.status_json(), indent=2))
    return 0


def cmd_autonomous_verify(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools import autonomous_loop as al  # noqa: PLC0415

    setup = Path(args.setup_json.strip()) if args.setup_json.strip() else None
    if setup and not setup.is_absolute():
        setup = ROOT / setup
    code, msgs = al.verify(allow_dirty=bool(args.allow_dirty), setup_json=setup)
    for m in msgs:
        print(m)
    return code


def cmd_metrics_emit(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools.metrics_bundle import emit_metrics_bundle  # noqa: PLC0415

    cj = Path(args.check_json.strip())
    sj = Path(args.setup_json.strip())
    if not cj.is_absolute():
        cj = ROOT / cj
    if not sj.is_absolute():
        sj = ROOT / sj
    bundle = emit_metrics_bundle(check_json_path=cj, setup_json_path=sj)
    text = json.dumps(bundle, indent=2)
    if args.out.strip():
        out = Path(args.out.strip())
        if not out.is_absolute():
            out = ROOT / out
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text + "\n", encoding="utf-8")
        print(str(out.relative_to(ROOT)))
    else:
        print(text)
    return 0


def cmd_setup_audit(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools import spaghetti_setup_audit as ssa  # noqa: PLC0415

    return ssa.cmd_setup_audit(args)


def cmd_setup_sync(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools import spaghetti_setup_audit as ssa  # noqa: PLC0415

    return ssa.cmd_setup_sync(args)


def cmd_trigger_eval(args: argparse.Namespace) -> int:
    _ensure_repo_root()
    from despaghettify.tools.metrics_bundle import emit_metrics_bundle  # noqa: PLC0415

    cj = Path(args.check_json.strip())
    sj = Path(args.setup_json.strip())
    if not cj.is_absolute():
        cj = ROOT / cj
    if not sj.is_absolute():
        sj = ROOT / sj
    bundle = emit_metrics_bundle(check_json_path=cj, setup_json_path=sj)
    out = {
        "fires": bundle["trigger_policy_fires"],
        "per_category_trigger_fires": bundle["per_category_trigger_fires"],
        "trigger_policy_basis": bundle.get("trigger_policy_basis", "anteil_pct"),
        "m7": bundle["m7"],
        "m7_anteil_pct_gewichtet": bundle["metric_a"]["m7"],
        "m7_ref": bundle["m7_ref"],
        "category_scores": bundle["category_scores"],
        "source": bundle.get("source"),
    }
    print(json.dumps(out, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Despaghettify hub automation CLI.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_check = sub.add_parser("check", help="Run AST scan, ds005, extra greps; print JSON (and optional --out).")
    p_check.add_argument("--out", type=str, default="", help="Write JSON report to this path (under repo if relative).")
    p_check.add_argument(
        "--with-metrics",
        action="store_true",
        help="If despaghettify/spaghetti-setup.json exists, embed metrics_bundle (heuristic v2) in the JSON output.",
    )
    p_check.set_defaults(func=cmd_check)

    p_pf = sub.add_parser("solve-preflight", help="Verify DS-id is open in Information input list.")
    p_pf.add_argument("--ds", required=True, help="e.g. DS-016")
    p_pf.add_argument(
        "--override-input-list",
        default="",
        metavar="PATH",
        help="CI/test only: markdown under despaghettify/tools/fixtures/ with § Information input list "
        "(must contain ## Information input list … ## Recommended implementation order).",
    )
    p_pf.set_defaults(func=cmd_solve_preflight)

    p_wpv = sub.add_parser(
        "wave-plan-validate",
        help="Validate a wave_plan.json against the despaghettify schema (exit 2 on validation errors).",
    )
    p_wpv.add_argument("--file", required=True, help="Path to wave_plan JSON (repo-relative or absolute).")
    p_wpv.add_argument(
        "--check-primary-paths",
        action="store_true",
        help="Require each sub_wave.primary_paths entry to exist under repo root (optional strict check).",
    )
    p_wpv.add_argument(
        "--gate-prefix-allowlist",
        default="",
        help="Comma-separated command prefixes; if set, each gate_command must start with one of them.",
    )
    p_wpv.set_defaults(func=cmd_wave_plan_validate)

    p_list = sub.add_parser("open-ds", help="Print open DS-ids (bold rows) from Information input list.")
    p_list.set_defaults(func=cmd_open_ds)

    p_ai = sub.add_parser(
        "autonomous-init",
        help="Create despaghettify/state/artifacts/autonomous_loop/autonomous_state.json (exit 2 if exists without --force).",
    )
    p_ai.add_argument("--force", action="store_true", help="Overwrite existing autonomous session state.")
    p_ai.set_defaults(func=cmd_autonomous_init)

    p_aa = sub.add_parser(
        "autonomous-advance",
        help="Legal transition for autonomous loop (exit 2 on rule violation). Kinds: backlog-solve, main-check, main-solve.",
    )
    p_aa.add_argument(
        "--kind",
        required=True,
        help="backlog-solve | main-check | main-solve",
    )
    p_aa.add_argument("--ds", default="", help="Required for solve kinds, e.g. DS-016")
    p_aa.add_argument("--check-json", default="", help="Optional path relative to repo for main-check.")
    p_aa.set_defaults(func=cmd_autonomous_advance)

    p_as = sub.add_parser("autonomous-status", help="Print JSON session status and next hints.")
    p_as.set_defaults(func=cmd_autonomous_status)

    p_av = sub.add_parser(
        "autonomous-verify",
        help="Verify autonomous_state vs open-ds, optional HEAD, dirty tree; exit 1 advisory stall, 2 hard fail.",
    )
    p_av.add_argument(
        "--allow-dirty",
        action="store_true",
        help="Allow git dirty worktree outside ignored prefixes.",
    )
    p_av.add_argument(
        "--setup-json",
        default="",
        metavar="PATH",
        help="Optional spaghetti-setup.json for trigger_eval line in output.",
    )
    p_av.set_defaults(func=cmd_autonomous_verify)

    p_me = sub.add_parser(
        "metrics-emit",
        help="Emit metrics_bundle JSON from check JSON + spaghetti-setup.json (heuristic v2).",
    )
    p_me.add_argument("--check-json", required=True, help="Path to check --out JSON (repo-relative ok).")
    p_me.add_argument(
        "--setup-json",
        default="despaghettify/spaghetti-setup.json",
        help="Path to spaghetti-setup.json mirror.",
    )
    p_me.add_argument("--out", default="", help="Write bundle to this path (repo-relative ok).")
    p_me.set_defaults(func=cmd_metrics_emit)

    p_te = sub.add_parser(
        "trigger-eval",
        help="Print trigger policy evaluation from check JSON + spaghetti-setup.json.",
    )
    p_te.add_argument("--check-json", required=True, help="Path to check --out JSON.")
    p_te.add_argument(
        "--setup-json",
        default="despaghettify/spaghetti-setup.json",
        help="Path to spaghetti-setup.json mirror.",
    )
    p_te.set_defaults(func=cmd_trigger_eval)

    p_sa = sub.add_parser(
        "setup-audit",
        help="Compare spaghetti-setup.md (canonical) to spaghetti-setup.json; optional check JSON vs md bars.",
    )
    p_sa.add_argument(
        "--setup-md",
        default="despaghettify/spaghetti-setup.md",
        help="Canonical policy Markdown (repo-relative ok).",
    )
    p_sa.add_argument(
        "--setup-json",
        default="despaghettify/spaghetti-setup.json",
        help="Machine mirror JSON (repo-relative ok).",
    )
    p_sa.add_argument(
        "--check-json",
        default="",
        help="Optional check --with-metrics JSON: show Anteil % vs bars from md.",
    )
    p_sa.add_argument("--json", action="store_true", help="Emit JSON report on stdout.")
    p_sa.set_defaults(func=cmd_setup_audit)

    p_sy = sub.add_parser(
        "setup-sync",
        help="Write spaghetti-setup.json from spaghetti-setup.md (canonical tables → machine mirror).",
    )
    p_sy.add_argument(
        "--setup-md",
        default="despaghettify/spaghetti-setup.md",
        help="Canonical policy Markdown (repo-relative ok).",
    )
    p_sy.add_argument(
        "--setup-json",
        default="despaghettify/spaghetti-setup.json",
        help="JSON path to write (repo-relative ok).",
    )
    p_sy.add_argument(
        "--dry-run",
        action="store_true",
        help="Print JSON to stdout only; stderr shows target path (no write).",
    )
    p_sy.set_defaults(func=cmd_setup_sync)

    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
