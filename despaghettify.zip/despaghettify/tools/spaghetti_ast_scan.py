"""AST metrics for structure / spaghetti reviews. See despaghettify/spaghetti-check-task.md.

Paths are resolved from this file's location (repository root = two levels above
``despaghettify/tools/``), so the process **current working directory** need not be the repo root.
"""
from __future__ import annotations

import ast
import importlib.util
from collections import Counter
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[2]

_MAGIC_INT_SKIP = frozenset({0, 1, 2, -1})


def _repo_rel(p: Path) -> str:
    try:
        return p.relative_to(_REPO_ROOT).as_posix()
    except ValueError:
        return p.as_posix()


IGNORE = (".state_tmp", "/site/", "node_modules", ".venv", "venv", "__pycache__")
ROOTS = [
    _REPO_ROOT / "backend" / "app",
    _REPO_ROOT / "world-engine" / "app",
    _REPO_ROOT / "ai_stack",
    _REPO_ROOT / "story_runtime_core",
    _REPO_ROOT / "tools" / "mcp_server",
    _REPO_ROOT / "administration-tool",
]


def walk(root: Path):
    for p in root.rglob("*.py"):
        s = p.as_posix()
        if any(x in s for x in IGNORE):
            continue
        yield p


def nest_depth(body: list[ast.stmt], d: int = 0) -> int:
    m = d
    for b in body:
        if isinstance(b, (ast.If, ast.For, ast.AsyncFor, ast.While, ast.With, ast.Try)):
            m = max(m, d + 1)
            for attr in ("body", "orelse", "handlers", "finalbody"):
                sub = getattr(b, attr, None)
                if isinstance(sub, list):
                    m = max(m, nest_depth(sub, d + 1))
    return m


def _magic_int_literal_count(node: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    """Heuristic: int ``ast.Constant`` in function body excluding tiny sentinels."""
    c = 0
    for sub in ast.walk(node):
        if isinstance(sub, ast.Constant) and type(sub.value) is int:
            if sub.value in _MAGIC_INT_SKIP:
                continue
            c += 1
    return c


def metrics(path: Path):
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return []
    out = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end = getattr(n, "end_lineno", None) or n.lineno
            out.append(
                (
                    n.name,
                    end - n.lineno + 1,
                    nest_depth(n.body, 0),
                    path,
                    _magic_int_literal_count(n),
                )
            )
    return out


def _count_python_files() -> int:
    n = 0
    for r in ROOTS:
        if r.exists():
            for _ in walk(r):
                n += 1
    return n


def collect_ast_stats() -> dict:
    """Programmatic metrics for despaghettify/tools/despaghettify.py and CI (same logic as main())."""
    allm: list = []
    for r in ROOTS:
        if r.exists():
            for p in walk(r):
                allm.extend(metrics(p))
    long50 = [x for x in allm if x[1] > 50]
    long100 = [x for x in allm if x[1] > 100]
    deep6 = [x for x in allm if x[2] >= 6]
    deep5 = [x for x in allm if x[2] >= 5]
    deep4 = [x for x in allm if x[2] >= 4]
    deep3 = [x for x in allm if x[2] >= 3]
    name_counts = Counter(x[0] for x in allm)
    dup_name_funcs = sum(1 for x in allm if name_counts[x[0]] > 1)
    magic_ge_5 = sum(1 for x in allm if x[4] >= 5)
    control_heavy = sum(1 for x in allm if x[2] >= 3 or x[1] > 80)
    long100.sort(key=lambda x: -x[1])
    deep6.sort(key=lambda x: (-x[2], -x[1]))
    top12 = [
        {"name": name, "lines": lines, "nest_depth": nd, "path": _repo_rel(p)}
        for name, lines, nd, p, _magic in long100[:12]
    ]
    top6n = [
        {"name": name, "lines": lines, "nest_depth": nd, "path": _repo_rel(p)}
        for name, lines, nd, p, _magic in deep6[:6]
    ]
    ate = _REPO_ROOT / "backend" / "app" / "runtime" / "ai_turn_executor.py"
    ai_turn_extra: dict | None = None
    if ate.exists():
        raw_lines = len(ate.read_text(encoding="utf-8", errors="replace").splitlines())
        ex = [x for x in metrics(ate) if x[0] == "execute_turn_with_ai"]
        ai_turn_extra = {
            "file_lines": raw_lines,
            "execute_turn_with_ai": (
                {"lines": ex[0][1], "nest_depth": ex[0][2]} if ex else None
            ),
        }
    _ics_path = Path(__file__).resolve().parent / "import_cycle_share.py"
    _spec = importlib.util.spec_from_file_location("_despag_import_cycle_share", _ics_path)
    _ics = importlib.util.module_from_spec(_spec)
    assert _spec.loader is not None
    _spec.loader.exec_module(_ics)
    c1m = _ics.backend_app_cycle_file_share(_REPO_ROOT)
    return {
        "total_functions": len(allm),
        "total_python_files": _count_python_files(),
        "count_over_50_lines": len(long50),
        "count_over_100_lines": len(long100),
        "count_nesting_ge_3": len(deep3),
        "count_nesting_ge_4": len(deep4),
        "count_nesting_ge_5": len(deep5),
        "count_nesting_ge_6": len(deep6),
        "count_functions_magic_int_literals_ge_5": magic_ge_5,
        "count_functions_duplicate_name_across_files": dup_name_funcs,
        "count_functions_control_flow_heavy": control_heavy,
        "c1_files_in_import_cycles_pct": c1m["c1_files_in_import_cycles_pct"],
        "c1_import_graph_files": c1m["c1_graph_files"],
        "c1_files_in_cycles": c1m["c1_files_in_cycles"],
        "top12_longest": top12,
        "top6_nesting": top6n,
        "ai_turn_executor": ai_turn_extra,
    }


def main() -> None:
    stats = collect_ast_stats()
    allm_n = stats["total_functions"]
    long50_n = stats["count_over_50_lines"]
    long100_n = stats["count_over_100_lines"]
    deep6_n = stats["count_nesting_ge_6"]
    print("Total functions:", allm_n)
    print(">50 lines:", long50_n, ">100 lines:", long100_n, "nesting>=6:", deep6_n)
    print("Top 12 longest:")
    for row in stats["top12_longest"]:
        print(
            f"  {row['lines']:4d}L depth~{row['nest_depth']} {row['path']}:{row['name']}"
        )
    print("Top 6 nesting:")
    for row in stats["top6_nesting"]:
        print(
            f"  depth {row['nest_depth']} {row['lines']:4d}L {row['path']}:{row['name']}"
        )
    extra = stats.get("ai_turn_executor")
    if extra:
        print("ai_turn_executor.py lines:", extra["file_lines"])
        if extra.get("execute_turn_with_ai"):
            et = extra["execute_turn_with_ai"]
            print("execute_turn_with_ai:", et["lines"], "lines depth~", et["nest_depth"])


if __name__ == "__main__":
    main()
