#!/usr/bin/env python3
"""Copy Despaghettify hub skills into `.cursor/skills/` for Cursor project skill discovery.

Canonical sources: despaghettify/superpowers/<skill-name>/SKILL.md
Targets:          .cursor/skills/<skill-name>/SKILL.md

Run from repository root after editing any skill under despaghettify/superpowers/:
  python despaghettify/tools/sync_despag_skills.py

Optional: pass --check to exit 1 if .cursor copies differ (CI guard).
"""
from __future__ import annotations

import argparse
import filecmp
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
SRC_ROOT = ROOT / "despaghettify" / "superpowers"
DST_ROOT = ROOT / ".cursor" / "skills"


def sync(*, check_only: bool) -> int:
    if not SRC_ROOT.is_dir():
        print(f"Missing source: {SRC_ROOT}", file=sys.stderr)
        return 2
    skill_dirs = [p for p in SRC_ROOT.iterdir() if p.is_dir() and (p / "SKILL.md").is_file()]
    if not skill_dirs:
        print(f"No */SKILL.md under {SRC_ROOT}", file=sys.stderr)
        return 2

    mismatches: list[str] = []
    for src_dir in sorted(skill_dirs, key=lambda p: p.name):
        name = src_dir.name
        src = src_dir / "SKILL.md"
        dst = DST_ROOT / name / "SKILL.md"
        if check_only:
            if not dst.is_file():
                mismatches.append(f"missing {dst.relative_to(ROOT)}")
            elif not filecmp.cmp(src, dst, shallow=False):
                mismatches.append(f"differ {dst.relative_to(ROOT)}")
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            print(f"synced {name} -> {dst.relative_to(ROOT)}")

    if check_only:
        if mismatches:
            print("Skill sync drift:\n" + "\n".join(mismatches), file=sys.stderr)
            return 1
        print("OK: .cursor/skills matches despaghettify/superpowers")
        return 0
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument(
        "--check",
        action="store_true",
        help="Exit 1 if copies are missing or differ from canonical SKILL.md files.",
    )
    args = ap.parse_args()
    return sync(check_only=args.check)


if __name__ == "__main__":
    raise SystemExit(main())
